%% MEASURE_KPI3_RECOVERY_TIME.m — proposal KPI #3: DQN vs Rule-Based decision speed
%
% REFRAMED (2026-09-16): the original version of this script simulated
% "recovery cycles" with a mock BER-halving loop that never called sim() or
% consulted either policy's actual action choice -- the reported cycle counts
% were identical for DQN and Rule-Based regardless of which was "tested",
% because nothing in the loop actually depended on the policy at all.
%
% Root cause of why "cycles" was the wrong framing to begin with: in this
% system, every countermeasure action is applied ONCE to the link model
% (apply_countermeasure.m, D28). Both DQN and Rule-Based are deterministic policies
% -- given a fixed state, each picks exactly one action and converges
% immediately. There is no real iterative "cycles to converge" dynamic in
% this architecture to measure.
%
% What DOES meaningfully differ between the two policies, and IS already
% measured with real data, is DECISION SPEED: Rule-Based is a lookup table
% (a few dB and a switch-case -- effectively instant); DQN is a real neural
% network forward pass (a few ms). This script measures that directly:
%   - Rule-based latency: REAL timed call to rule_based_policy.m per threat
%   - DQN latency + rule agreement + recovery: pulled from the STRUCT saved
%     in results/closed_loop_diagnostic_results.mat by
%     run_closed_loop_diagnostic.m -- not parsed from the .txt report.
%
% FIX (2026-09-19): the previous version parsed closed_loop_diagnostic_report.txt
% with strsplit(txt,'--- Threat: ') and several regexes tuned to an OLDER
% report layout. The report format changed when the sliding-window fix (D16)
% was added (blocks are now "--- <threat> @ SNR=<x> dB ---", one per
% threat-SNR pair, not one per threat) -- the old parsing silently matched
% nothing and made this script throw "Could not parse any threat blocks".
% Reading the .mat struct directly is immune to any future report-text
% reformatting, since it is the same struct run_closed_loop_diagnostic.m
% already builds and saves.
%
% Each threat has one DQN/recovery data point per SNR (run_closed_loop_diagnostic.m
% sweeps all SNR points); this script averages across SNR to report one
% representative row per threat, and also reports the full-sweep means.
%
% Output: results/kpi3_measurement.txt

close all; clc;
fprintf('=== KPI #3: Decision Speed (DQN vs Rule-Based) ===\n\n');

MAX_STALE_DAYS = 0.5;   % 12 hours -- the pipeline changes faster than days

%% 1. Ensure a fresh diagnostic .mat exists (real Simulink+CNN+DQN data)
mat_path = 'results/closed_loop_diagnostic_results.mat';
need_rerun = ~exist(mat_path, 'file');
if ~need_rerun
    d = dir(mat_path);
    need_rerun = (now - datenum(d.date)) > MAX_STALE_DAYS;
end
if need_rerun
    fprintf('No fresh %s found -- running run_closed_loop_diagnostic...\n', mat_path);
    run_closed_loop_diagnostic;
end

L = load(mat_path, 'results');
res = L.results;
if isempty(res)
    error('results/closed_loop_diagnostic_results.mat contains an empty results struct.');
end

%% 2. Aggregate per-threat (averaged across the SNR sweep)
threats = unique({res.threat}, 'stable');
n = numel(threats);

dqn_latency_ms = zeros(1, n);
recovery_pct   = zeros(1, n);
rule_rec_pct   = nan(1, n);
agrees_frac    = zeros(1, n);
rule_action    = cell(1, n);

for i = 1:n
    mask = strcmp({res.threat}, threats{i});
    sub  = res(mask);
    dqn_latency_ms(i) = mean([sub.dqn_latency_ms]);
    if isfield(sub, 'rec_vs_clean')
        recovery_pct(i) = mean([sub(~[sub.missed]).rec_vs_clean], 'omitnan');   % KPI #2 definition (D27)
    else
        recovery_pct(i) = mean([sub.recovery_pct], 'omitnan');
    end
    if isfield(sub, 'rec_rule')
        rule_rec_pct(i) = mean([sub.rec_rule], 'omitnan');                          % rule outcome, same runs
    end
    agrees_frac(i)    = mean([sub.agrees_with_rule]);
    rule_action{i}    = sub(1).rule_based_action;
end

fprintf('Loaded %d threats (SNR-averaged) from %s\n\n', n, mat_path);

%% 3. Time the REAL rule_based_policy.m call per threat (actual execution, not mocked)
rule_latency_ms = zeros(1, n);
N_TIMING_REPEATS = 1000;   % lookup is sub-ms; repeat and average for a stable reading
for i = 1:n
    t0 = tic;
    for r = 1:N_TIMING_REPEATS
        [~, ~] = rule_based_policy(threats{i});
    end
    rule_latency_ms(i) = (toc(t0) / N_TIMING_REPEATS) * 1000;
end

%% 4. Report
report = {};
report{end+1} = '=== KPI #3: Decision Speed (DQN vs Rule-Based) ===';
report{end+1} = sprintf('Generated: %s', datestr(now));
report{end+1} = '';
report{end+1} = 'Decision latency of both policies, the link quality each achieves on the same';
report{end+1} = 'closed-loop runs, and (section 5) recovery time in decision cycles from the';
report{end+1} = 'episodic closed loop with dwell/hysteresis.';
report{end+1} = '';
report{end+1} = 'DQN latency/recovery/agreement are averaged across the full SNR sweep';
report{end+1} = '(each threat has one data point per SNR point in the diagnostic run).';
report{end+1} = '';
report{end+1} = sprintf('%-22s %12s %12s %8s %14s %14s', 'Threat', 'DQN (ms)', 'Rule (ms)', 'Agree%', 'DQN rec (clean)', 'Rule rec (clean)');
for i = 1:n
    report{end+1} = sprintf('%-22s %12.3f %12.5f %7.0f%% %14s %14s', threats{i}, dqn_latency_ms(i), ...
        rule_latency_ms(i), 100*agrees_frac(i), pct_or_na(recovery_pct(i)), pct_or_na(rule_rec_pct(i))); %#ok<SAGROW>
end
report{end+1} = '';
report{end+1} = sprintf('Mean DQN latency:  %.3f ms', mean(dqn_latency_ms));
report{end+1} = sprintf('Mean Rule latency: %.5f ms', mean(rule_latency_ms));
report{end+1} = sprintf('Speed ratio: Rule-Based is ~%.0fx faster than DQN (lookup table vs neural net inference)', ...
    mean(dqn_latency_ms) / mean(rule_latency_ms));
report{end+1} = sprintf('DQN-vs-Rule agreement (overall, all threats x SNR): %.1f%%', 100*mean(agrees_frac));
report{end+1} = '';
report{end+1} = 'NOTE: both policies act through the same physical countermeasure model';
report{end+1} = '(apply_countermeasure.m, D28), so agreement and recovery compare decision';
report{end+1} = 'quality only. Disagreement is no longer cosmetic: actions differ in effect.';
report{end+1} = '';
report{end+1} = 'Interpretation: the rule is effectively instant (a lookup); the DQN costs about a';
report{end+1} = 'millisecond of inference, small next to the ~10 ms detection path. Both are far';
report{end+1} = 'faster than the dwell of a few frames, so recovery time is set by detection and';
report{end+1} = 'hysteresis rather than by the policy''s compute time (section 5).';

if ~exist('results', 'dir'), mkdir('results'); end
%% 5. Recovery time in decision cycles (episodic closed loop, D31)
report{end+1} = '';
report{end+1} = '--- Recovery time in decision cycles (run_closed_loop_episodes.m, D31) ---';
if isfile('results/closed_loop_episodes.mat')
    EP = load('results/closed_loop_episodes.mat', 'E', 'threats', 'degraded', 'EBNO_LIST', 'cfg_keys', 'DWELL', 'HOLD');
    if ~isfield(EP.E, 'status')
        report_closed_loop_episodes;
        EP = load('results/closed_loop_episodes.mat', 'E', 'threats', 'degraded', 'EBNO_LIST', 'cfg_keys', 'DWELL', 'HOLD');
    end
    report{end+1} = sprintf('Threat onset mid-stream; dwell %d cycles, hold %d cycles; medians in cycles after onset.', EP.DWELL, EP.HOLD);
    report{end+1} = 'T_recover over episodes the threat actually degraded and no countermeasure was active at onset.';
    report{end+1} = sprintf('%-24s %7s %9s %11s %9s %8s %8s', 'configuration', 'T_act', 'T_recover', 'recovered', 'pre-cfg', 'switches', 'goodput');
    for c = 1:numel(EP.cfg_keys)
        m  = [EP.E.needs] & strcmp({EP.E.cfg}, EP.cfg_keys{c});
        mt = m & ismember({EP.E.status}, {'recovered', 'not recovered'});
        report{end+1} = sprintf('%-24s %7s %9s %6d/%-4d %9d %8.2f %8.2f', EP.cfg_keys{c}, ...
            pct_med([EP.E(m).T_act]), pct_med([EP.E(mt).T_rec]), sum(strcmp({EP.E(m).status}, 'recovered')), sum(mt), ...
            sum([EP.E(m).preconf]), mean([EP.E(m).switches]), mean([EP.E(m).goodput])); %#ok<SAGROW>
    end
else
    report{end+1} = 'Not available -- run run_closed_loop_episodes.m.';
end

fid = fopen('results/kpi3_measurement.txt', 'w');
for i = 1:numel(report), fprintf(fid, '%s\n', report{i}); end
fclose(fid);
for i = 1:numel(report), fprintf('%s\n', report{i}); end
fprintf('\nSaved results/kpi3_measurement.txt\n');
fprintf('\n=== KPI #3 Complete ===\n');

%% Local function
function s = pct_or_na(x)
if isnan(x), s = 'N/A'; else, s = sprintf('%.1f%%', x); end
end

function s = pct_med(x)
x = x(~isnan(x));
if isempty(x), s = '-'; else, s = sprintf('%.0f', median(x)); end
end