%% UAV-GCS Adaptive Secure Communications System - Parameters
% Central parameter file. Run this FIRST — it saves params.mat that all
% other scripts load.
% Author: Adi Suliman, Bar Dvir Hassan
% Created: 2026-09-01
close all; clc;%% ========== PROJECT PHASE ==========
params.phase        = 'A4';          % current phase
params.active_channel = 'Rician';    % [ACTIVE] channel used now
params.target_channel = 'Rician';    % scope target
%% ========== MODULATION & TRANSMISSION ==========
params.mod_type            = 'QPSK';   % [ACTIVE] modulation scheme
params.mod_order           = 4;        % [ACTIVE] QPSK -> 4
params.symbol_rate         = 1e6;      % [ACTIVE] 1 Msym/s
params.samples_per_symbol  = 4;        % [ACTIVE] oversampling (A3+, spectral features)
params.sps                 = params.samples_per_symbol;
%% ========== FRAME STRUCTURE ==========
params.bits_per_frame = 1000;          % [ACTIVE] information bits per frame
params.crc_bits       = 32;            % [FUTURE] CRC for Packet Loss Rate metric (A6)
params.frame_length   = params.bits_per_frame + params.crc_bits;  % total bits/frame
%% ========== CHANNEL MODEL ==========
% [A4-hybrid] Pulse shaping (RRC) — enables spectrogram for CNN
params.rolloff      = 0.25;            % [ACTIVE] RRC roll-off factor
params.filter_span  = 10;              % [ACTIVE] RRC filter span (symbols)
params.rician_k      = 10;             % [ACTIVE] K-factor (dB), strong LoS
params.carrier_freq  = 2.4e9;          % [ACTIVE] 2.4 GHz ISM
params.nominal_range = 100;            % [FUTURE] nominal link range (m)

% [A3] UAV platform velocity & derived Doppler
% Platform: small tactical ISR UAV — DoD Group 1 (Skylark/Raven class)
% Operational speed envelope: 50-120 km/h (13.9-33.3 m/s) -> Doppler 111-267 Hz @ 2.4 GHz.
% Speed is a CONTINUOUS parameter (any real value inside the envelope, not only
% whole km/h). The dataset generator draws a random real-valued speed per block
% of frames; the GUI accepts decimals. fd_max = v * fc / c.
% v_nominal (20 m/s = 72 km/h -> fd = 160 Hz) is the default cruise speed used by
% every script that does not sweep speed (DQN reward table, EXP, survivability map).
params.speed_kmh_min = 50;                       % [km/h] envelope lower bound
params.speed_kmh_max = 120;                      % [km/h] envelope upper bound
params.v_min     = params.speed_kmh_min/3.6;     % [m/s]  13.89
params.v_max     = params.speed_kmh_max/3.6;     % [m/s]  33.33
params.v_nominal = 20;      % [m/s] nominal cruise (72 km/h) — default simulation Doppler
params.c_light   = 3e8;     % [m/s] speed of light
params.fd_max    = params.v_nominal * params.carrier_freq / params.c_light;  % [Hz] ~160 @ 20 m/s

% [A4] Threat injection parameters
params.active_threat = 'jamming';   % 'none' | 'jamming' (more threats added incrementally)
params.jsr_db        = 10;          % [dB] Jamming-to-Signal Ratio (barrage jammer power)
params.burst_duty    = 0.3;         % [A4] Noise Burst: fraction of time jammer is ON (0-1)
params.burst_period  = 100;         % [A4] Noise Burst: on/off cycle length (symbols)
params.path_loss_db  = 10;          % [A4] Path Loss: attenuation (dB) applied to Tx signal
params.fault_duty     = 0.15;       % [A4] Antenna Fault: fraction of time fault is active (0-1)
params.fault_period   = 200;        % [A4] Antenna Fault: fault on/off cycle length (symbols)
params.fault_atten_db = 30;         % [A4] Antenna Fault: severe attenuation during fault (dB)
params.spoof_sir_db   = 0;          % [A4] Spoofing: Spoof-to-Signal Ratio (dB), 0 = equal power
params.reactive_threshold = 0.5;    % [A4] Reactive Jamming: signal-energy threshold to trigger jammer

% [A-ext] Benign Interference: weak NON-MALICIOUS in-band noise (e.g. neighboring
% WiFi/ISM device). Deliberately much weaker than active jamming (-10 to -2 dB vs
% jamming's 0-16 dB) so it never overlaps the attack power range -- exists to give
% the CNN a "looks-like-something but isn't an attack" class for FAR measurement.
params.benign_int_db  = -6;         % [A-ext] Benign Interference power (dB), weak/non-malicious

% [A-ext] Sweeping Jammer: like jamming, but only dwells on our channel a fraction
% of the time (spends the rest sweeping other channels). Severity axis is still
% jsr_db (consistent with jamming/noise_burst/reactive_jamming), duty/period are
% fixed structural constants (same pattern as burst_duty/burst_period for noise_burst).
params.sweep_duty    = 0.15;        % [A-ext] Sweeping Jammer: fraction of time dwelling on our channel
params.sweep_period  = 300;         % [A-ext] Sweeping Jammer: full sweep cycle length (symbols, longer than noise_burst's 100)

% [D28] Countermeasure physics (apply_countermeasure.m)
params.cm_acr_db      = 30;         % [dB] rejection of an interferer left on another channel
params.cm_rate_factor = 4;          % rate_reduce: data rate / 4 -> +6 dB processing gain, goodput x0.25
params.cm_n_rx        = 2;          % spatial_diversity: receive antennas combined by MRC (+3 dB)

%% ========== NOISE & SWEEP ==========
params.EbNo_dB    = 0:2:10;            % [ACTIVE] Eb/N0 sweep range (dB)
params.num_frames = 1000;             % [ACTIVE] frames accumulated per Eb/N0 point

%% ========== SEQUENCE WINDOWING (CNN-LSTM, Phase B-exp) ==========
% Used by build_sequence_index.m / extract_spectrograms_seq.m / train_detector_lstm.m
% to group consecutive same-class frames (from data/dataset.mat) into windows
% for the LSTM temporal branch. Does NOT affect the existing CNN-only pipeline.
params.seq_len    = 8;    % [LSTM] frames per sequence window (5-10 per plan)
params.seq_stride = 4;    % [LSTM] step between window starts (4 = 50% overlap;
                           %        set = seq_len for non-overlapping windows)

%% ========== FLAGS ==========
params.plot_enable = true;
params.verbose     = true;
%% ========== DERIVED PARAMETERS ==========
params.bits_per_symbol   = log2(params.mod_order);
params.symbols_per_frame = params.frame_length / params.bits_per_symbol;
params.samples_per_frame = params.symbols_per_frame * params.sps;
params.frame_duration    = params.symbols_per_frame / params.symbol_rate;
%% ========== DISPLAY ==========
if params.verbose
    fprintf('\n========== UAV-GCS LINK PARAMETERS ==========\n');
    fprintf('Phase:            %s  (channel: %s)\n', params.phase, params.active_channel);
    fprintf('Modulation:       %s\n', params.mod_type);
    fprintf('Symbol Rate:      %.2e sym/s\n', params.symbol_rate);
    fprintf('Bits/Frame:       %d (+ %d CRC [FUTURE])\n', params.bits_per_frame, params.crc_bits);
    fprintf('Symbols/Frame:    %d\n', params.symbols_per_frame);
    fprintf('Channel:          Rician (K=%.1f dB)\n', params.rician_k);
    fprintf('Carrier Freq:     %.1f GHz\n', params.carrier_freq/1e9);
    fprintf('Range:            %d m [FUTURE]\n', params.nominal_range);
    fprintf('UAV Velocity:     %.1f m/s (%.1f km/h) nominal | envelope %.1f-%.1f km/h (%.1f-%.1f m/s)\n', ...
            params.v_nominal, params.v_nominal*3.6, params.speed_kmh_min, params.speed_kmh_max, params.v_min, params.v_max);
    fprintf('Doppler envelope: %.0f-%.0f Hz (nominal fd_max %.0f Hz)\n', ...
            params.v_min*params.carrier_freq/params.c_light, params.v_max*params.carrier_freq/params.c_light, params.fd_max);
    fprintf('Max Doppler fd:   %.1f Hz  (normalized %.2e)\n', ...
            params.fd_max, params.fd_max/params.symbol_rate);
    fprintf('Active Threat:    %s (JSR=%.0f dB)\n', params.active_threat, params.jsr_db);
    fprintf('Eb/N0 Range:      %.0f to %.0f dB\n', min(params.EbNo_dB), max(params.EbNo_dB));
    fprintf('Frames per SNR:   %d\n', params.num_frames);
    fprintf('Sequence window:  len=%d, stride=%d (LSTM)\n', params.seq_len, params.seq_stride);
    fprintf('=============================================\n\n');
end
%% ========== SAVE PARAMETERS ==========
save('params.mat', 'params');
fprintf('Parameters saved to params.mat\n');